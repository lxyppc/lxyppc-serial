#ifndef QRENCODER_H
#define QRENCODER_H

#include <QImage>
#include "qrencode.h"

class QREncoder
{
public:
    QREncoder(const QString& content, int margin = 3, int size = 5, int mode = QR_MODE_8, int level = QR_ECLEVEL_L)
        :m_content(content.toAscii()),m_margin(margin),m_size(size),m_mode(mode),m_level(level),m_8bit(0)
    {
    }
    QREncoder(const QByteArray& content, int margin = 3, int size =5, int mode = QR_MODE_8, int level = QR_ECLEVEL_L)
        :m_content(content),m_margin(margin),m_size(size),m_mode(mode),m_level(level),m_8bit(1)
    {
    }

    int margin() const{ return m_margin;}
    void setMargin(int margin) { m_margin = margin; }

    QByteArray content()const { return m_content;}
    void setContent(const QByteArray& content) { m_content = content; m_8bit = 1;}

    QString string()const { return QString(m_content); }
    void setString(const QString& string) { m_content = string.toAscii(); m_8bit = 0;}

    int mode() const { return m_mode;}
    void setMode(int mode) { m_mode = mode;}

    int level() const { return m_level;}
    void setLevel(int level) { m_level = level;}

    bool casesensitive() const { return m_casesensitive; }
    void setCasesensitive(bool casesensitive) { m_casesensitive = casesensitive; }

    QImage toImage() const;

    static QImage toImage1(const QString& string){ QREncoder qr(string); return qr.toImage();}
    static QImage toImage2(const QString& string, int margin){ QREncoder qr(string,margin); return qr.toImage();}
    static QImage toImage3(const QString& string, int margin, int size){ QREncoder qr(string,margin,size); return qr.toImage();}
    static QImage toImage4(const QString& string, int margin, int size, int mode){ QREncoder qr(string,margin,size,mode); return qr.toImage();}
    static QImage toImage5(const QString& string, int margin, int size, int mode, int level){ QREncoder qr(string,margin,size,mode,level); return qr.toImage();}

    static QImage toImage6(const QByteArray& string){ QREncoder qr(string); return qr.toImage();}
    static QImage toImage7(const QByteArray& string, int margin){ QREncoder qr(string,margin); return qr.toImage();}
    static QImage toImage8(const QByteArray& string, int margin, int size){ QREncoder qr(string,margin,size); return qr.toImage();}
    static QImage toImage9(const QByteArray& string, int margin, int size, int mode){ QREncoder qr(string,margin,size,mode); return qr.toImage();}
    static QImage toImage10(const QByteArray& string, int margin, int size, int mode, int level){ QREncoder qr(string,margin,size,mode,level); return qr.toImage();}

private:
    QByteArray m_content;
    int m_margin;
    int m_size;
    int m_mode;
    int m_level;
    bool m_casesensitive;
    int m_8bit;
};

#endif // QRENCODER_H
