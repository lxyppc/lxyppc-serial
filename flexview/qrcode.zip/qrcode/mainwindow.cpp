#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qrencoder.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap map;
    map.load("123.gif");
    ui->label->setPixmap(map);
    QREncoder qr(QByteArray("hello world from qr code"));
    QImage img = qr.toImage();
    ui->label->setPixmap(QPixmap::fromImage(img));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
