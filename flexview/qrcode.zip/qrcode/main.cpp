#include <QtGui/QApplication>
#include "mainwindow.h"
extern "C" int main_xx(int argc, char **argv);
int main(int argc, char *argv[])
{
    main_xx(argc,argv);
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
